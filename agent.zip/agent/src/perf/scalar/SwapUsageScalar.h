/**********************************************************
 * File: SwapUsageScalar.h
 * Function: 
 *********************************************************/
#pragma once

#include "SampleMOScalar.h"




class CSwapUsageScalar : public CSampleMOScalar
{
public:
    CSwapUsageScalar();
    virtual ~CSwapUsageScalar();


    virtual void UpdateThrod();
    virtual double FetchData();


private:

};





















