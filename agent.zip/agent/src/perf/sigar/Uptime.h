/**********************************************************
 * File: Uptime.h
 * Function: 
 *********************************************************/
#pragma once

#include <string>

using namespace std;




class CUptime
{
public:
    CUptime(){};
    ~CUptime(){};


    double GetUptime();



};









