
#ifndef _APPPRCOCESSCONTROL_H_
#define _APPPRCOCESSCONTROL_H_

#include <iostream>
#include <string>

using namespace std;

class AppProcessControl
{
public:
	static int CtrlAppFunc(CtrlAppData &ctrlApp);
}

#endif

