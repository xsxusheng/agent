#!/bin/sh
db_version=`mysql -V`
echo $db_version
exit 0


