#!/bin/sh
mirrorha stop
echo succuss
exit 0
