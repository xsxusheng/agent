#!/bin/sh
mirrorha restart
echo succuss
exit 0
