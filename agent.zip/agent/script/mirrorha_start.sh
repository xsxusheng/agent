#!/bin/sh
mirrorha start
echo succuss
exit 0
